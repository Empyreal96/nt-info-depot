Thank you for your interest in the Windows OS Internals Curriculum Resource Kit (CRK)!

The tools in this ZIP file are the ones referenced in the labs and demonstrations of the CRK units.

Note: this is a snapshot of tools that may have more up to date versions available on the internet.

The lab setup guide (WOSI-Lab-Setup.doc) is part in the main CRK download.

There are 3 subfolders with these tools:
	\Debugging Tools - latest version of the Microsoft Windows Debugging Tools
	   (for latest version, see http://www.microsoft.com/whdc/ddk/debugging)

	\Reskit - old Windows 2000 Resource Kit tools not shipped in the 2003 Resource Kit

	\x64 - 64-bit versions of 3 tools for x64 (AMD64 and Intel EM64T - Itanium versions are not available)

	\Kernrate - Kernel Profiler tool referred to in Unit OS3


